import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Edge {

  int node_start;
  int node_end;
  int weight;

  Edge(int node1, int node2, int wt) {
    node_start = node1;
    node_end = node2;
    weight = wt;
  }

  public int GetWeight() {
    return weight;
  }
}

public class Kruskal {

  private final int num_nodes;
  private final List<Edge> edgelist = new ArrayList<>();
  private final List<Integer> parent;
  private final List<Integer> rank;

  Kruskal(int num_nodes) {
    this.num_nodes = num_nodes;
    parent = new ArrayList<>(num_nodes);
    rank = new ArrayList<>(num_nodes);
  }

  public void AddEdge(Edge e) {
    edgelist.add(e);
  }

  public int FindParent(int node) {
    if (parent.get(node) == node) return node;

    return FindParent(parent.get(node));
  }

  public void KruskalMST(List<Edge> result) {

    for (int i = 0; i < num_nodes; i++) {
      parent.add(i, i);
      rank.add(i, 0);
    }
    edgelist.sort(Comparator.comparingInt(Edge::GetWeight));

    for (Edge e : edgelist) {

      int root1 = FindParent(e.node_start);
      int root2 = FindParent(e.node_end);
      if (root1 != root2) {
        result.add(e);
        if (rank.get(root1) < rank.get(root2)) {
          parent.set(root1, root2);
          rank.set(root2, rank.get(root2) + 1);
        } else {
          parent.set(root2, root1);
          rank.set(root1, rank.get(root1) + 1);
        }
      }
    }
  }

  public void DisplayEdges(List<Edge> result) {
    int cost = 0;
    System.out.print("\nEdges of minimum spanning tree : ");
    for (Edge edge : result) {
      System.out.print("[" + edge.node_start + "-" + edge.node_end + "]-(" + edge.weight + ") ");
      cost += edge.weight;
    }
    System.out.println("\nCost of minimum spanning tree : " + cost);
  }

  private static Kruskal create(
      int num_nodes,
      Edge a,
      Edge b,
      Edge c,
      Edge d,
      Edge e,
      Edge f,
      Edge g,
      Edge h,
      Edge i,
      Edge j) {
    Kruskal g2 = new Kruskal(num_nodes);
    g2.AddEdge(a);
    g2.AddEdge(b);
    g2.AddEdge(c);
    g2.AddEdge(d);
    g2.AddEdge(e);
    g2.AddEdge(f);
    g2.AddEdge(g);
    g2.AddEdge(h);
    g2.AddEdge(i);
    g2.AddEdge(j);
    return g2;
  }

  public static void main(String[] args) {

    int num_nodes = 6;

    Edge e1 = new Edge(0, 1, 4);
    Edge e2 = new Edge(0, 2, 1);
    Edge e3 = new Edge(0, 3, 5);
    Edge e4 = new Edge(1, 3, 2);
    Edge e5 = new Edge(1, 4, 3);
    Edge e6 = new Edge(1, 5, 3);
    Edge e7 = new Edge(2, 3, 2);
    Edge e8 = new Edge(2, 4, 8);
    Edge e9 = new Edge(3, 4, 1);
    Edge e10 = new Edge(4, 5, 3);

    Kruskal g1 = create(num_nodes, e1, e2, e3, e4, e5, e6, e7, e8, e9, e10);

    List<Edge> mst = new ArrayList<>();
    g1.KruskalMST(mst);
    g1.DisplayEdges(mst);

    num_nodes = 7;

    Edge a = new Edge(0, 1, 1);
    Edge b = new Edge(0, 2, 2);
    Edge c = new Edge(0, 3, 1);
    Edge d = new Edge(0, 4, 1);
    Edge e = new Edge(0, 5, 2);
    Edge f = new Edge(0, 6, 1);
    Edge g = new Edge(1, 2, 2);
    Edge h = new Edge(1, 6, 2);
    Edge i = new Edge(2, 3, 1);
    Edge j = new Edge(3, 4, 2);
    Edge k = new Edge(4, 5, 2);
    Edge l = new Edge(5, 6, 1);

    Kruskal g2 = create(num_nodes, a, b, c, d, e, f, g, h, i, j);
    g2.AddEdge(k);
    g2.AddEdge(l);

    mst.clear();
    g2.KruskalMST(mst);
    g2.DisplayEdges(mst);
  }
}
